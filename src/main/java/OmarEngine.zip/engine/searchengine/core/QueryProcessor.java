package engine.searchengine.core;

import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import org.bson.conversions.Bson;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import javax.print.Doc;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.stream.Collectors;

import static com.mongodb.client.model.Filters.eq;

public class QueryProcessor {
    String Query;
    MongoDatabase database;
    MongoClient mongoClient;
    private MongoCollection<org.bson.Document> collection, DocsCollection;
    Map<String,Double> docRelevanceScore=new HashMap<String,Double>();

    Map<String,String> occurencesMap =new HashMap<String,String>();
    Map<String,Double> tagsWeights=new HashMap<String,Double>();
    org.bson.Document doc;
    public QueryProcessor()
    {
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        database = mongoClient.getDatabase("SearchEngine");
        collection = database.getCollection("InvertedFile");
        tagsWeights.put("h1",1.0);
        tagsWeights.put("h2",0.85);
        tagsWeights.put("h3",0.7);
        tagsWeights.put("h4",0.5);
        tagsWeights.put("h5",0.3);
        tagsWeights.put("h6",0.1);
        tagsWeights.put("title",1.0);
        tagsWeights.put("p",0.1);
        tagsWeights.put("i",0.3);
        tagsWeights.put("b",0.8);
        tagsWeights.put("big",0.8);
        tagsWeights.put("li",0.2);
        tagsWeights.put("u",0.7);
        tagsWeights.put("th",0.5);
        tagsWeights.put("strong",0.8);
        tagsWeights.put("em",0.5);
    }

    public void PhraseSearch(String searchQuery) throws IOException, NoSuchAlgorithmException
    {
        searchQuery=searchQuery.toLowerCase(Locale.ROOT);
        String[] searchQueryArr=searchQuery.split(" ");
        Bson projectionFields = Projections.fields(
                Projections.include("token","DF","Docs"),
                Projections.excludeId());
        List<org.bson.Document> pages;
        //doc=collection.find(eq("token","abdallah")).projection(projectionFields).first();
        //pages=(List<org.bson.Document>)doc.get("Docs");
        //System.out.println(doc);
//        System.out.println(searchQuery);
//        System.out.println(searchQueryArr[0]);
        for (String token:searchQueryArr)
        {
            Map<String,Boolean> visitedPage;
            doc=collection.find(eq("token",token)).projection(projectionFields).first();
            System.out.println(doc);
            if(doc==null)
                continue;
            pages=doc.get("Docs",List.class);
            double DF=Integer.parseInt(doc.get("DF").toString());
            // System.out.println(DF);
            double TF;
            double IDF=DF;
            double totalTagWeight=0;
            //iterating on Docs that contain token
//            System.out.println(pages);
            for (int i = 0; i < pages.size(); i++)
            {
                //getting tag weight default value is of <p>
                String tag=pages.get(i).get("tag").toString();
                double tagWeight=(tagsWeights.containsKey(tag))?tagsWeights.get(tag):tagsWeights.get("p");
                //getting the page getting processed
                TF=Double.parseDouble(pages.get(i).get("TF").toString());
                String currentPage=pages.get(i).get("page").toString();

                if(docRelevanceScore.containsKey(currentPage))
                {
                    docRelevanceScore.put(currentPage,docRelevanceScore.get(currentPage)+TF*IDF*tagWeight);
                }
                else
                {
                    docRelevanceScore.put(currentPage,TF*IDF*tagWeight);
                }
            }

        }
        // System.out.println(docRelevanceScore);
        Document documentHTML;

        FetchType type=FetchType.FILE;
        Iterator<String> it=docRelevanceScore.keySet().iterator();
        Map<String, Double> tmpDocRScore = new HashMap<String, Double>();
        Map<String, String> occurrencesMap = new HashMap<String, String>();

        while(it.hasNext()) {
            String key=it.next();
            MongoCollection<org.bson.Document> collection = database.getCollection("InvertedFile");
            for(String word : (List<String>)Arrays.stream(searchQuery.toLowerCase().split(" ")).toList()){

                Bson projectionDoc = Projections.elemMatch("Docs", Filters.eq("page", key));

                FindIterable<org.bson.Document> result = collection.find(Filters.and(
                        Filters.eq("token", word),
                        Filters.elemMatch("Docs", Filters.eq("page", key))
                )).projection(projectionDoc);


//                System.out.println(result.first() == null);
                if (result == null) continue;

                for (org.bson.Document doc : result) {
                    List<org.bson.Document> docs =  doc.getList("Docs", org.bson.Document.class);
                    for (org.bson.Document document : docs) {
                        String occurrence = document.getString("occurrence");
                        if(occurrence.contains(searchQuery.toLowerCase())){
                            tmpDocRScore.put(key, docRelevanceScore.get(key));
                            occurrencesMap.put(key, occurrence);
                        }
                    }
                }


            }

        }
        docRelevanceScore = tmpDocRScore;
        this.occurencesMap = occurrencesMap;
//        System.out.println(docRelevanceScore);
    }

    public Map<String,Double> getDocRelevanceScore()
    {
        docRelevanceScore=docRelevanceScore.entrySet()
                .stream()
                .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));;
        return docRelevanceScore;
    }
    public Map<String,String> getOccurencesMap()
    {
        return occurencesMap;
    }

}

package engine.searchengine.core;

import com.mongodb.client.*;
import org.bson.Document;

import java.time.LocalDateTime;
import java.util.List;

public class IndexerWrapper {
    private static List<String> visitedLinksList;
    public IndexerWrapper(){
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("SearchEngine");
        MongoCollection<Document> collection = database.getCollection("VisitedLinks");
        if(collection.countDocuments() == 0) {
            System.out.println("No Documents Found in MongoDB");
        }


//        if (visitedLinksDocument == null){
//            System.out.println("No State Found in MongoDB");
//        }
        Indexer indexer = new Indexer();
        MongoCursor<Document> cursor;
        cursor = collection.find().iterator();
        // Loop over the collection to insert each document into the HashMap
        while (cursor.hasNext()) {
            // Get the document and extract the key-value pairs
            Document document = cursor.next();
            String url = document.getString("url");
            System.out.println("Indexing URL: " + url);
//            new Thread(() -> new Indexer().index(url, FetchType.URL)).start();
            indexer.index(url, FetchType.URL);

        }
        indexer.UpdateIDF();
    }
}

package engine.searchengine.core;

public enum FetchType {
    FILE, URL
}
package engine.searchengine.controllers;

import ch.qos.logback.core.joran.sanity.Pair;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import engine.searchengine.Models.ImageObject;
import engine.searchengine.Models.ResultObject;
import engine.searchengine.core.QueryProcessor;
import org.bson.Document;
import engine.searchengine.core.Ranker;
import org.bson.conversions.Bson;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.*;

//import javax.swing.text.Document;
import javax.swing.text.Element;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.sql.Time;
import java.time.LocalDateTime;
import java.util.*;


@RestController
@RequestMapping("query")
public class SearchController implements ErrorController {

    private final int PAGE_COUNT = 10;
    private static MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
    private static MongoDatabase database = mongoClient.getDatabase("SearchEngine");

    private static MongoCollection imgCollection = database.getCollection("Images");
    private static List<String> urls;

    private static String searchQuery;
    private int resultsCount = 0;

    private List<ImageObject> images = new ArrayList<>();


    public static String getTitle(String url)  {
        MongoCollection<Document> collection = database.getCollection("VisitedLinks");
        Document filter = new Document("url", url);
        Document result = collection.find(filter).first();

        return result.getString("title");
    }
    public static String getIcon(String url) throws URISyntaxException {
        MongoCollection<Document> collection = database.getCollection("VisitedLinks");
        Document filter = new Document("url", url);
        Document result = collection.find(filter).first();

        return result.getString("icon");
    }
    public static String getMostMatchingParagraph(String url,String query) {
        String mostMatchingParagraph = "";
        Map<String,Integer> text = new HashMap<>();

        MongoCollection<Document> collection = database.getCollection("InvertedFile");
        for(String word : (List<String>)Arrays.stream(query.toLowerCase().split(" ")).toList()){

            Bson projectionDoc = Projections.elemMatch("Docs", Filters.eq("page", url));

            Document result = collection.find(Filters.and(
                    Filters.eq("token", word),
                    Filters.elemMatch("Docs", Filters.and(Filters.eq("page", url), Filters.eq("tag", 'p')))
            )).projection(projectionDoc).first();

            if (result == null)
                result = collection.find(Filters.and(
                        Filters.eq("token", word),
                        Filters.elemMatch("Docs", Filters.and(Filters.eq("page", url)))
                )).projection(projectionDoc).first();


            System.out.println(result);
            if(result != null){
                String occurrence = result.getList("Docs", Document.class).get(0).getString("occurrence");
                if(text.containsKey(occurrence)) continue;
                mostMatchingParagraph += occurrence;
                text.put(occurrence,1);
                mostMatchingParagraph += "...";
                System.out.println("The Occurence is : " + mostMatchingParagraph);
            }
        }

        return mostMatchingParagraph;
    }


    @GetMapping("/count")
    public int count() {
        return resultsCount;
    }

    @GetMapping("/images")
    public List<ImageObject> images() {
        return images;
    }

    @GetMapping
    public List<ResultObject> search(@RequestParam String query, @RequestParam int page) {
//        query = "hello \"real madrid\" my man";
        Map<String, Double> docRelevanceScore;
        int firstQuoteIndex = -1;
        int lastQuoteIndex = -1;
        QueryProcessor queryProcessor = new QueryProcessor();
        if(searchQuery == null || query != searchQuery){
            // ex : hi "hello world" no // size = 19 fIdx = 3 lIdx = 15
            String phraseSearchQuery = "";
            firstQuoteIndex = query.indexOf('"');
            System.out.println("firstQuoteIndex : " + firstQuoteIndex);
            lastQuoteIndex = query.indexOf('"', firstQuoteIndex + 1);
            System.out.println("lastQuoteIndex : " + lastQuoteIndex);
            if(firstQuoteIndex != -1 && lastQuoteIndex != -1){
                phraseSearchQuery = query.substring(firstQuoteIndex + 1, lastQuoteIndex);
                System.out.println(phraseSearchQuery);
                try {
                    queryProcessor.PhraseSearch(phraseSearchQuery);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }

                docRelevanceScore = queryProcessor.getDocRelevanceScore();
                urls = (List<String>)docRelevanceScore.keySet().stream().toList();

            }else{

                Ranker ranker = new Ranker();

                ranker.setSearchQuery(query);

                ranker.calculateRelevancy();

                ranker.calculatePopularity();

                docRelevanceScore = ranker.getDocRelevanceScore();

                urls = (List<String>)docRelevanceScore.keySet().stream().toList();

            }

            images = new ArrayList<>();
            int count = 0;
            for (String url : urls) {
                FindIterable<Document> imgs = imgCollection.find(Filters.eq("page", url)).limit(10);
                for(Document doc : imgs){
                    images.add(new ImageObject(doc.getString("page"), doc.getString("alt") , doc.getString("url")));
                }
                if(count > 10)
                    break;
                count++;
            }
            resultsCount = docRelevanceScore.size();

        }


        List<String> paragraphs = new ArrayList<>();
        String mostMatchingParagraph = "";
        List<ResultObject> results = new ArrayList<>();
        for (int i = (page-1) * PAGE_COUNT; i < (page)* PAGE_COUNT;i++) {
            if(urls.size() > i){
                if(firstQuoteIndex != -1 && lastQuoteIndex != -1){
                    Map<String, String> occurences = queryProcessor.getOccurencesMap();
                    mostMatchingParagraph = occurences.get(urls.get(i));
                }else
                    mostMatchingParagraph = getMostMatchingParagraph(urls.get(i),query);

                mostMatchingParagraph = mostMatchingParagraph.substring(0, Math.min(mostMatchingParagraph.length(), 300));

                URL url = null;

                try {
                    url = new URL(urls.get(i));
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
                String domain = url.getHost();

                try {
                    int index = (domain.substring(0,4).equals("www.")) ? 1 : 0;
                    results.add(new ResultObject(urls.get(i), getTitle(urls.get(i)), mostMatchingParagraph, getIcon(urls.get(i)), domain.split("\\.")[index].substring(0, 1).toUpperCase() + domain.split("\\.")[index].substring(1)));
                } catch (URISyntaxException e) {
                    throw new RuntimeException(e);
                }
            } else break;
        }

        return results;
    }
}